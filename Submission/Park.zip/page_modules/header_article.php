<?php echo '
        <article id="brand_intro">
        <div id="text_wrapper">
            <h2>Genuine Bread</h2>
            <p class="article_description">We bake everyday and love to provide healthy bread with our neighborhood. All ingredient used for baking is from our local farm in Alberta. Come by anytime to our stores and get some fresh bread</p>
            <a href="brand.php" class="moreinfo_btn">More Information</a>
        </div>
    </article>
</header>
';
?>